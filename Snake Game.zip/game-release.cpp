
#ifndef TETRIS_CPP_
#define TETRIS_CPP_
#include "util.h"
#include <iostream>
#include<vector>
#include <fstream>
#include<algorithm>
//#include<cstdlib>
#include<ctime> 
#include<string>
//#include<sys/wait.h>
//#include<stdlib.h>
//#include<stdio.h>
#include<unistd.h>
#include<sstream>
#include<cmath>      // for basic math functions such as cos, sin, sqrt
using namespace std;

#define FPS 15

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
void SetCanvasSize(int width, int height) {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
    glMatrixMode( GL_MODELVIEW);
    glLoadIdentity();
}

// Define maximum size for the snake
#define MAX_SNAKE_LENGTH 100
// Snake representation
int snake_length = 1; // initial snake length
int snake_x[MAX_SNAKE_LENGTH] = {320, 310, 300}; // X coordinates of snake segments
int snake_y[MAX_SNAKE_LENGTH] = {400, 400, 400}; // Y coordinates of snake segments

// Board dimensions
#define BOARD_WIDTH 60
#define BOARD_HEIGHT 60
#define CELL_SIZE 10
double startx=320,starty=400;

void DrawBoard(int width, int height) {
    float color[] = {0.5, 0.5, 0.5}; // Grey color for the board
    for (int i = 0; i < width; ++i) {
        for (int j = 0; j < height; ++j) {
            // Calculate the top left corner of the cell
            int x = i * CELL_SIZE;
            int y = j * CELL_SIZE;
            DrawSquare(x, y, CELL_SIZE, color);
        }
    }
}

// Function to draw the snake on the canvas
void DrawSnake() {
    // Draw the head of the snake as a circle
    float headColor[] = {0.0, 1.0, 0.0}; // Green color for the head
    DrawCircle(snake_x[0], snake_y[0], CELL_SIZE / 2, headColor);

    // Draw the body of the snake as squares
    float bodyColor[] = {0.0, 0.5, 0.0}; // Darker green color for the body
    for (int i = 1; i < snake_length; ++i) {
        DrawSquare(snake_x[i] - CELL_SIZE / 2, snake_y[i] - CELL_SIZE / 2, CELL_SIZE, bodyColor);
    }
}

int dirX = 0;
int dirY = 0;

// Score and Food definitions
int score = 0;
#define FOOD_COUNT 5
int food_x[FOOD_COUNT];
int food_y[FOOD_COUNT];
bool food_active[FOOD_COUNT]; // Whether the food is active and should be drawn
int food_timer[FOOD_COUNT]; // Timer for each food

// Function to initialize food positions
void InitFood() {
    for (int i = 0; i < FOOD_COUNT; ++i) {
        food_active[i] = true;
        food_timer[i] = 15000; // 15 seconds in milliseconds
        
        bool valid;
        do {
            valid = true;
            // Generate random positions for food ensuring they meet the specified criteria
            food_x[i] = (rand() % BOARD_WIDTH) * CELL_SIZE;
            food_y[i] = (rand() % BOARD_HEIGHT) * CELL_SIZE;
            
            // Check the new position against all other active food items
            for (int j = 0; j < i; ++j) {
                if (food_active[j]) {
                    // Check same row, column, and diagonals
                    if (food_y[i] == food_y[j] || food_x[i] == food_x[j] ||
                        abs(food_x[i] - food_x[j]) == abs(food_y[i] - food_y[j])) {
                        valid = false;
                        break;
                    }
                }
            }
        } while (!valid);
    }
}

// Function to draw food items
void DrawFood() {
    float color[] = {1.0, 0.0, 0.0}; // Red color for the food
    for (int i = 0; i < FOOD_COUNT; ++i) {
        if (food_active[i]) {
            DrawSquare(food_x[i], food_y[i], CELL_SIZE, color);
        }
    }
}

// Function to increase the snake's length
void IncreaseSnakeLength() {
    if (snake_length < MAX_SNAKE_LENGTH) {
        snake_x[snake_length] = snake_x[snake_length - 1];
        snake_y[snake_length] = snake_y[snake_length - 1];
        snake_length++;
    }
}

// Function to update the score display
void DisplayScore() {
    stringstream ss;
    ss << "Score = " << score;
    DrawString(50, 625, ss.str(), colors[GREEN]);
}

// Function to respawn food at a new position
void RespawnFood(int index) {
    food_timer[index] = 15000; // Reset timer to 15 seconds
    food_active[index] = true; // Make food active

    bool valid;
    do {
        valid = true;
        // Generate new random position for food ensuring they meet the specified criteria
        food_x[index] = (rand() % BOARD_WIDTH) * CELL_SIZE;
        food_y[index] = (rand() % BOARD_HEIGHT) * CELL_SIZE;
        
        // Check the new position against all other active food items
        for (int j = 0; j < FOOD_COUNT; ++j) {
            if (j != index && food_active[j]) {
                // Check same row, column, and diagonals
                if (food_y[index] == food_y[j] || food_x[index] == food_x[j] ||
                    abs(food_x[index] - food_x[j]) == abs(food_y[index] - food_y[j])) {
                    valid = false;
                    break;
                }
            }
        }
    } while (!valid);
}

void CheckFoodEaten() {
    for (int i = 0; i < FOOD_COUNT; ++i) {
        if (food_active[i]) {
            if (snake_x[0] == food_x[i] && snake_y[0] == food_y[i]) {
                IncreaseSnakeLength(); // Increase the snake's length
                score += 5; // Increase the score
                RespawnFood(i); // Respawn the food item at a new location
            }
        }
    }
}

#define HURDLE_COUNT 3
#define HURDLE_LIFETIME 30000 // 30 seconds in milliseconds

// Hurdle properties as parallel arrays
int hurdle_x[HURDLE_COUNT][4]; // x coordinates of the hurdles' parts
int hurdle_y[HURDLE_COUNT][4]; // y coordinates of the hurdles' parts
bool hurdle_active[HURDLE_COUNT]; // Active status of hurdles
int hurdle_timer[HURDLE_COUNT]; // Timer for each hurdle
int hurdle_length[HURDLE_COUNT]; // Length of each hurdle

// Function to initialize hurdles
void InitHurdles() {
    for (int i = 0; i < HURDLE_COUNT; ++i) {
        hurdle_active[i] = true;
        hurdle_timer[i] = HURDLE_LIFETIME;
        hurdle_length[i] = (rand() % 4) + 2; // Length between 2 and 5

        // Initialize the first part of the hurdle
        hurdle_x[i][0] = (rand() % BOARD_WIDTH) * CELL_SIZE;
        hurdle_y[i][0] = (rand() % BOARD_HEIGHT) * CELL_SIZE;

        // Continue placing parts to the right to create a horizontal line
        for (int j = 1; j < hurdle_length[i]; ++j) {
            hurdle_x[i][j] = hurdle_x[i][j - 1] + CELL_SIZE;
            hurdle_y[i][j] = hurdle_y[i][0];
        }
    }
}

// Function to draw hurdles
void DrawHurdles() {
    float color[] = {0.0, 0.0, 1.0}; // Blue color for the hurdles
    for (int i = 0; i < HURDLE_COUNT; ++i) {
        if (hurdle_active[i]) {
            for (int j = 0; j < hurdle_length[i]; ++j) {
                DrawSquare(hurdle_x[i][j], hurdle_y[i][j], CELL_SIZE, color);
            }
        }
    }
}

void RespawnHurdle(int index) {
    hurdle_timer[index] = HURDLE_LIFETIME; // Reset timer
    hurdle_active[index] = true; // Make hurdle active

    bool valid;
    do {
        valid = true;
        // Generate new random position for the first part of the hurdle
        hurdle_x[index][0] = (rand() % BOARD_WIDTH) * CELL_SIZE;
        hurdle_y[index][0] = (rand() % BOARD_HEIGHT) * CELL_SIZE;

        // Generate the rest of the hurdle parts based on the first part
        for (int j = 1; j < hurdle_length[index]; ++j) {
            hurdle_x[index][j] = hurdle_x[index][j - 1] + CELL_SIZE;
            hurdle_y[index][j] = hurdle_y[index][0];
        }

        // Check the new position against the snake and food
        for (int j = 0; j < snake_length; ++j) {
            for (int k = 0; k < hurdle_length[index]; ++k) {
                if (snake_x[j] == hurdle_x[index][k] && snake_y[j] == hurdle_y[index][k]) {
                    valid = false;
                    break;
                }
            }
        }
        for (int j = 0; j < FOOD_COUNT; ++j) {
            if (food_active[j]) {
                for (int k = 0; k < hurdle_length[index]; ++k) {
                    if (food_x[j] == hurdle_x[index][k] && food_y[j] == hurdle_y[index][k]) {
                        valid = false;
                        break;
                    }
                }
            }
        }
    } while (!valid);
}

bool CheckHurdleCollision() {
    for (int i = 0; i < HURDLE_COUNT; ++i) {
        if (hurdle_active[i]) {
            for (int j = 0; j < hurdle_length[i]; ++j) {
                if (snake_x[0] == hurdle_x[i][j] && snake_y[0] == hurdle_y[i][j]) {
                    return true; // Collision detected
                }
            }
        }
    }
    return false; // No collision
}

bool CheckSelfCollision() {
    for (int i = 1; i < snake_length; ++i) {
        if (snake_x[0] == snake_x[i] && snake_y[0] == snake_y[i]) {
            return true;
        }
    }
    return false;
}

void KeepSnakeInBounds() {
    if (snake_x[0] < 0 || snake_x[0] >= BOARD_WIDTH * CELL_SIZE ||
        snake_y[0] < 0 || snake_y[0] >= BOARD_HEIGHT * CELL_SIZE) {
        cout << "Game Over! The snake has hit the wall." << endl;
        exit(0);
    }
}


void SaveHighestScore(int score) {
    ofstream out_file("highest_score.txt");
    if (out_file.is_open()) {
        out_file << score;
        out_file.close();
    }
}

void UpdatePlayerHistory(int score) {
    ofstream out_file("player_history.txt", ios::app); // Append mode
    if (out_file.is_open()) {
        out_file << score << endl;
        out_file.close();
    }
}

int LoadHighestScore() {
    int high_score = 0;
    ifstream in_file("highest_score.txt");
    if (in_file.is_open()) {
        in_file >> high_score;
        in_file.close();
    }
    return high_score;
}

void DisplayPlayerHistory() {
    string line;
    ifstream in_file("player_history.txt");
    if (in_file.is_open()) {
        while (getline(in_file, line)) {
            cout << line << endl;
        }
        in_file.close();
    }
}


bool gamePlaying = false;
void GameOver() {
    int high_score = LoadHighestScore();
    if (score > high_score) {
        SaveHighestScore(score);
        cout << "New high score: " << score << endl;
    } else {
        cout << "Game over. Your score: " << score << endl;
    }
    UpdatePlayerHistory(score);
    gamePlaying = false; // Reset gamePlaying to false

    
    // For now, let's just exit
    exit(0);
}
int power_food_x, power_food_y;
bool power_food_active = false;
int power_food_timer = 0;

void DisplayPowerFood() {
    if (power_food_active) {
        float color[] = {1.0, 1.0, 0.0}; // Yellow color for the power food
        DrawSquare(power_food_x, power_food_y, CELL_SIZE, color);
    }
}

void SpawnPowerFood() {
    // Call this function every minute to spawn power food
    power_food_x = (rand() % BOARD_WIDTH) * CELL_SIZE;
    power_food_y = (rand() % BOARD_HEIGHT) * CELL_SIZE;
    power_food_active = true;
    power_food_timer = 15000; // 15 seconds in milliseconds
}

void CheckPowerFoodEaten() {
    if (power_food_active && snake_x[0] == power_food_x && snake_y[0] == power_food_y) {
        score += 20;
        power_food_active = false; // The power food is eaten, make it inactive
    }
}


int power_food_spawn_timer = 0; 

void MoveSnake() {
    // Move the body of the snake
    for (int i = snake_length - 1; i > 0; --i) {
        snake_x[i] = snake_x[i - 1];
        snake_y[i] = snake_y[i - 1];
    }
    // Update the head position
    snake_x[0] += dirX * CELL_SIZE;
    snake_y[0] += dirY * CELL_SIZE;

    if (CheckHurdleCollision()) {
         GameOver();
    }

}

void DrawMenu() {
    // Clear the canvas
    glClearColor(0, 0, 0, 0); // Black background
    glClear(GL_COLOR_BUFFER_BIT);

    // Set up colors for the menu items
    float colorActive[] = {1.0, 1.0, 0.0}; // Yellow color for the active menu item
    float colorInactive[] = {1.0, 1.0, 1.0}; // White color for inactive menu items

    // Draw each menu item
    DrawString(300, 550, "Start Game", colorActive);
    DrawString(300, 500, "High Score", colorInactive);
    DrawString(300, 450, "Game History", colorInactive);
    DrawString(300, 400, "Exit", colorInactive);

    // Swap the buffers to display the menu
    glutSwapBuffers();
}


void ExitGame() {
    exit(0);
}

void Display() {
    // Clear the canvas and set the background color
    glClearColor(0, 0, 0, 0); // Black background
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw the board
    DrawBoard(BOARD_WIDTH, BOARD_HEIGHT);

    // Draw the food
    DrawFood();

    // Draw the snake
    DrawSnake();

    DisplayPowerFood();

    // Display the score
    DisplayScore();

    // Draw Thhe Hurdle 
    DrawHurdles();

    // Swap the buffers to display the current drawing
    glutSwapBuffers();
}


void ShowHighScore() {
    // Clear the canvas
    glClearColor(0, 0, 0, 0); // Black background
    glClear(GL_COLOR_BUFFER_BIT);

    int high_score = LoadHighestScore();
    stringstream ss;
    ss << "High Score: " << high_score;

    // Set up color for the text
    float color[] = {1.0, 1.0, 1.0}; // White color for the text

    // Draw the high score
    DrawString(300, 400, ss.str(), color);

    // Swap the buffers to display the high score
    glutSwapBuffers();
}

void ShowPlayerHistory() {
    // Clear the canvas
    glClearColor(0, 0, 0, 0); // Black background
    glClear(GL_COLOR_BUFFER_BIT);

    ifstream in_file("player_history.txt");
    string line;
    int y_position = 550; // Start drawing from the top and move down

    // Set up color for the text
    float color[] = {1.0, 1.0, 1.0}; // White color for the text

    if (in_file.is_open()) {
        while (getline(in_file, line)) {
            // Draw each line (score) from the file
            DrawString(300, y_position, line, color);
            y_position -= 30; // Move down for the next entry
        }
        in_file.close();
    }

    // Swap the buffers to display the player history
    glutSwapBuffers();
}

// Function to reset the snake's position and length
void ResetSnake() {
    snake_length = 4; // Reset the initial snake length
    snake_x[0] = 320; snake_y[0] = 400; // Reset the initial position of the snake's head
    dirX = 1; dirY = 0; // Reset the initial movement direction of the snake
    // Reset the rest of the snake's body if necessary
    for (int i = 1; i < snake_length; i++) {
        snake_x[i] = snake_x[0] - i * CELL_SIZE;
        snake_y[i] = snake_y[0];
    }
}
// Global variable to track the game state

int selectedMenuItem = 0;

void StartGame() {
    // Initialize or reset game state
    InitFood();
    InitHurdles();
    ResetSnake();
    score = 0;
    gamePlaying = true;

    // Switch the display function to the game screen
    glutDisplayFunc(Display);

    // Force the screen to redraw
    glutPostRedisplay();
}




void PrintableKeys(unsigned char key, int x, int y) {
    if (key == KEY_ESC/* Escape key ASCII*/) {
        exit(1); // exit the program when escape key is pressed.
    }
    if (key == 'R' || key=='r'/* Escape key ASCII*/) {
        //exit(1); // exit the program when escape key is pressed.
    	//aswangle+=90;
    }
    
  if (key == 27 /* Escape key ASCII */) {
        ExitGame(); // exit the program when escape key is pressed.
    } else if (key == 13 && !gamePlaying) { // ASCII for Enter key
        switch (selectedMenuItem) {
            case 0: StartGame(); break;
            case 1: ShowHighScore(); break;
            case 2: ShowPlayerHistory(); break;
            case 3: ExitGame(); break;
          
        }
    }
    
    glutPostRedisplay();
}


void Timer(int m) {
    
    power_food_spawn_timer += 1000 / FPS;
    if (power_food_spawn_timer >= 15000) { 
        SpawnPowerFood();
        power_food_spawn_timer = 0; // Reset the timer after spawning
    }


    for (int i = 0; i < FOOD_COUNT; ++i) {
        if (food_active[i]) {
            food_timer[i] -= 1000 / FPS; // Subtract the elapsed time
            if (food_timer[i] <= 0) {
                // If the timer has expired, deactivate the food
               RespawnFood(i);
            }
        }
    }

     // Update the timers for each hurdle
    for (int i = 0; i < HURDLE_COUNT; ++i) {
        if (hurdle_active[i]) {
            hurdle_timer[i] -= 1000 / FPS;
            if (hurdle_timer[i] <= 0) {
                RespawnHurdle(i);
            }
        }
    }

    if (power_food_active) {
        power_food_timer -= 1000 / FPS;
        if (power_food_timer <= 0) {
            power_food_active = false;
        }
    }

    // Check for self-collision
    if (CheckSelfCollision()) {
        GameOver();
    }

    // Ensure the snake stays within bounds
    KeepSnakeInBounds();


    CheckFoodEaten(); 
    CheckPowerFoodEaten(); 

    MoveSnake(); // Move the snake based on current direction
     if (CheckHurdleCollision()) {
        // Handle collision (end game, reset snake, etc.)
        cout << "Game Over! The snake has hit a hurdle." << endl;
        exit(0);
    }

    glutPostRedisplay();
    // once again we tell the library to call our Timer function after next 1000/FPS
    glutTimerFunc(1000.0 / FPS, Timer, 0);
}


void NonPrintableKeys(int key, int x, int y) {
     if (!gamePlaying) {
        // Navigate the menu
        if (key == GLUT_KEY_UP) {
            selectedMenuItem = max(0, selectedMenuItem - 1);
        } else if (key == GLUT_KEY_DOWN) {
            selectedMenuItem = min(3, selectedMenuItem + 1); // Assuming you have 4 menu items
        }
        DrawMenu();
        glutPostRedisplay();
    } else {
        // Control the snake movement
        if (key == GLUT_KEY_LEFT && dirX != 1) {
            dirX = -1;
            dirY = 0;
        } else if (key == GLUT_KEY_RIGHT && dirX != -1) {
            dirX = 1;
            dirY = 0;
        } else if (key == GLUT_KEY_UP && dirY != -1) {
            dirX = 0;
            dirY = 1;
        } else if (key == GLUT_KEY_DOWN && dirY != 1) {
            dirX = 0;
            dirY = -1;
        }
    }
    MoveSnake();
}


int main(int argc, char*argv[]) {
    int width = 650, height = 650; 

    glutInit(&argc, argv); // initialize the graphics library FIRST
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
    glutInitWindowPosition(50, 50); // set the initial position of our window
    glutInitWindowSize(width, height); // set the size of our window
    glutCreateWindow("PF's Snake Game"); // set the title of our game window

    SetCanvasSize(width, height); // set the number of pixels...

    InitRandomizer(); // seed the random number generator...
    InitFood(); // Initialize food
    InitHurdles(); // Initialize hurdles

    glutDisplayFunc(DrawMenu); // Set the function for the initial screen

    glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
    glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters

    glutTimerFunc(5.0 / FPS, Timer, 0); // Set the Timer function

    glutMainLoop(); // Start the main GLUT loop
    return 1; // Exit with success
}
#endif /* Snake Game */

